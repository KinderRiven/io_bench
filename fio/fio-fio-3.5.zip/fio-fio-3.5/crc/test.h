#ifndef FIO_CRC_TEST_H
#define FIO_CRC_TEST_H

int fio_crctest(const char *type);

#endif
